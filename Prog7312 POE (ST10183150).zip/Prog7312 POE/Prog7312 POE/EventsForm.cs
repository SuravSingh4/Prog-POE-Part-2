﻿using Prog7312_POE;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Linq;

namespace MunicipalServicesApp
{
    public partial class EventsForm : Form
    {
        // Sorted dictionary to store events by date
        private SortedDictionary<DateTime, List<string>> eventsDictionary;

        // Priority queue for handling high-priority events
        private PriorityQueue<string> eventNotifications = new PriorityQueue<string>();

        // HashSet to store unique event categories
        private HashSet<string> eventCategories = new HashSet<string>
        {
            "Community", "Festival", "Holiday", "Market"
        };

        // Dictionary to store user search history (category, count)
        private Dictionary<string, int> searchHistory = new Dictionary<string, int>();

        public EventsForm()
        {
            InitializeComponent();
            InitializeEvents();
            InitializeCategorySearch();
            LoadEventsFromFile(); // Load events from file at startup
        }

        // Initialize with some sample events
        private void InitializeEvents()
        {
            eventsDictionary = new SortedDictionary<DateTime, List<string>>();

            // Add some sample events
            AddEvent(new DateTime(2024, 10, 20), "Community Cleanup", "Community");
            AddEvent(new DateTime(2024, 11, 5), "Local Market Festival", "Festival");
            AddEvent(new DateTime(2024, 12, 12), "Holiday Lights Show", "Holiday");

            // Populate the event list
            PopulateEventList();
        }

        // Method to initialize category ComboBox
        private void InitializeCategorySearch()
        {
            cmbCategorySearch.DataSource = eventCategories.ToList();
        }

        // Method to add events to the dictionary and categories
        private void AddEvent(DateTime date, string eventName, string category)
        {
            if (eventsDictionary.ContainsKey(date))
            {
                eventsDictionary[date].Add(eventName);
            }
            else
            {
                eventsDictionary[date] = new List<string> { eventName };
            }

            // Add the event to its category
            eventCategories.Add(category);
        }

        // Method to populate the ListBox with events
        private void PopulateEventList()
        {
            listBoxEvents.Items.Clear();
            foreach (var entry in eventsDictionary)
            {
                string date = entry.Key.ToShortDateString();
                foreach (string eventName in entry.Value)
                {
                    listBoxEvents.Items.Add($"{date} - {eventName}");
                }
            }
        }

        // Search button click event
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            string searchTerm = txtSearch.Text.ToLower();
            DateTime selectedDate = dateTimePickerSearch.Value;

            //Validate input before searching
            if (string.IsNullOrWhiteSpace(searchTerm) && selectedDate == DateTime.MinValue)
            {
                MessageBox.Show("Please enter a search term or select a date.");
                return;
            }

            //Log the search term for future recommendations

           LogSearch(searchTerm);

            //Filter events based on search term or date

           var filteredEvents = eventsDictionary
               .Where(d => d.Key.Date == selectedDate || d.Value.Any(ev => ev.ToLower().Contains(searchTerm)))
               .ToList();

            // Display results
            listBoxEvents.Items.Clear();
            foreach (var entry in filteredEvents)
            {
                string date = entry.Key.ToShortDateString();
                foreach (string eventName in entry.Value)
                {
                    listBoxEvents.Items.Add($"{date} - {eventName}");
                }
            }

            if (listBoxEvents.Items.Count == 0)
            {
                listBoxEvents.Items.Add("No events found for the given search.");
            }

            // Optionally call recommendations after 3 searches
            if (searchHistory.Count >= 3)
            {
                RecommendEvents();
            }
        }

        // Search by category using HashSet
        private void SearchByCategory(string category)
        {
            if (eventCategories.Contains(category))
            {
                listBoxEvents.Items.Clear();
                foreach (var entry in eventsDictionary)
                {
                    foreach (string eventName in entry.Value)
                    {
                        if (eventName.ToLower().Contains(category.ToLower()))
                        {
                            listBoxEvents.Items.Add($"{entry.Key.ToShortDateString()} - {eventName}");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("No events found for the given category.");
            }
        }

        // Method to log user searches for recommendations
        private void LogSearch(string searchTerm)
        {
            if (searchHistory.ContainsKey(searchTerm))
            {
                searchHistory[searchTerm]++;
            }
            else
            {
                searchHistory[searchTerm] = 1;
            }
        }

        // Recommend events based on user search history
        private void RecommendEvents()
        {
            if (searchHistory.Count > 0)
            {
                // Find the most searched term
                string topSearch = searchHistory.OrderByDescending(x => x.Value).FirstOrDefault().Key;
                MessageBox.Show($"Based on your searches, you might be interested in events related to: {topSearch}");
            }
        }

        // Priority Queue for urgent or special events (optional usage)
        private void AddUrgentEvent(string eventName, int priority)
        {
            eventNotifications.Enqueue(eventName, priority);
        }

        private void ShowNextUrgentEvent()
        {
            if (!eventNotifications.IsEmpty())
            {
                string nextEvent = eventNotifications.Dequeue();
                MessageBox.Show($"Next urgent event: {nextEvent}");
            }
        }

        // Timer tick event to show urgent events periodically
        private void eventUrgencyTimer_Tick(object sender, EventArgs e)
        {
            ShowNextUrgentEvent();
        }

        // Save events to file for persistence
        private void SaveEventsToFile()
        {
            using (StreamWriter sw = new StreamWriter("events.txt"))
            {
                foreach (var entry in eventsDictionary)
                {
                    foreach (string eventName in entry.Value)
                    {
                        sw.WriteLine($"{entry.Key.ToShortDateString()}|{eventName}");
                    }
                }
            }
        }

        // Load events from file at startup
        private void LoadEventsFromFile()
        {
            if (File.Exists("events.txt"))
            {
                using (StreamReader sr = new StreamReader("events.txt"))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        var data = line.Split('|');
                        DateTime date = DateTime.Parse(data[0]);
                        string eventName = data[1];
                        AddEvent(date, eventName, ""); // Assuming category is optional
                    }
                }
            }
        }

        // Search by date range (optional)
        private void SearchByDateRange(DateTime startDate, DateTime endDate)
        {
            var filteredEvents = eventsDictionary
                .Where(d => d.Key.Date >= startDate && d.Key.Date <= endDate)
                .ToList();

            listBoxEvents.Items.Clear();
            foreach (var entry in filteredEvents)
            {
                string date = entry.Key.ToShortDateString();
                foreach (string eventName in entry.Value)
                {
                    listBoxEvents.Items.Add($"{date} - {eventName}");
                }
            }

            if (listBoxEvents.Items.Count == 0)
            {
                listBoxEvents.Items.Add("No events found for the given date range.");
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
           MainForm MainForm = new MainForm();
            MainForm.Show();

                // Close the current form and go back to the previous one
                this.Hide();  // Assuming this closes the current EventsForm
            


        }




        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void EventsForm_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private List<string> SearchEvents(string searchTerm)
        {
            List<string> matchingEvents = new List<string>();

           
            foreach (var entry in eventsDictionary)
            {
                foreach (var eventName in entry.Value)
                {
                    if (eventName.Contains(searchTerm))
                    {
                        matchingEvents.Add(eventName);
                    }
                }
            }

            return matchingEvents;
        }


        private void btnSearchClick_Click(object sender, EventArgs e)
        {

            
                // Get the search term from the text box
                string searchTerm = txtSearch.Text;

                // Perform the search 
                var searchResults = SearchEvents(searchTerm);

                // Display search results 
                if (searchResults.Count > 0)
                {
                    MessageBox.Show($"Found {searchResults.Count} matching events.");
                }
                else
                {
                    MessageBox.Show("No events found.");
                }
            }


        }
    

}


    

