﻿namespace Prog7312_POE
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReportIssues = new System.Windows.Forms.Button();
            this.btnLEA = new System.Windows.Forms.Button();
            this.btnSRS = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnReportIssues
            // 
            this.btnReportIssues.BackColor = System.Drawing.Color.Aqua;
            this.btnReportIssues.Location = new System.Drawing.Point(335, 153);
            this.btnReportIssues.Margin = new System.Windows.Forms.Padding(4);
            this.btnReportIssues.Name = "btnReportIssues";
            this.btnReportIssues.Size = new System.Drawing.Size(425, 44);
            this.btnReportIssues.TabIndex = 0;
            this.btnReportIssues.Text = "Report Issues";
            this.btnReportIssues.UseVisualStyleBackColor = false;
            // 
            // btnLEA
            // 
            this.btnLEA.BackColor = System.Drawing.Color.Aqua;
            this.btnLEA.Location = new System.Drawing.Point(335, 251);
            this.btnLEA.Margin = new System.Windows.Forms.Padding(4);
            this.btnLEA.Name = "btnLEA";
            this.btnLEA.Size = new System.Drawing.Size(425, 44);
            this.btnLEA.TabIndex = 1;
            this.btnLEA.Text = "Local Events and Announcements";
            this.btnLEA.UseVisualStyleBackColor = false;
            this.btnLEA.Click += new System.EventHandler(this.btnLEA_Click);
            // 
            // btnSRS
            // 
            this.btnSRS.BackColor = System.Drawing.Color.White;
            this.btnSRS.Location = new System.Drawing.Point(335, 342);
            this.btnSRS.Margin = new System.Windows.Forms.Padding(4);
            this.btnSRS.Name = "btnSRS";
            this.btnSRS.Size = new System.Drawing.Size(425, 44);
            this.btnSRS.TabIndex = 2;
            this.btnSRS.Text = "Service Request Status";
            this.btnSRS.UseVisualStyleBackColor = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnSRS);
            this.Controls.Add(this.btnLEA);
            this.Controls.Add(this.btnReportIssues);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnReportIssues;
        private System.Windows.Forms.Button btnLEA;
        private System.Windows.Forms.Button btnSRS;
    }
}

