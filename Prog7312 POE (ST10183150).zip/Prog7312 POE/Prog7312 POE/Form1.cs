﻿using MunicipalServicesApp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog7312_POE
{
   
        public partial class MainForm : Form
        {
            public MainForm()
            {
                InitializeComponent();

                // Enable Report Issues button
                btnReportIssues.Enabled = true;

                btnLEA.Enabled = true;


            //disable final button
            btnSRS.Enabled = false;

                // Wire up the Report Issues button to open the form
                btnReportIssues.Click += BtnReportIssues_Click;
            }

            // Event handler for Report Issues button
            private void BtnReportIssues_Click(object sender, EventArgs e)
            {
                // Open the Report Issues form
                ReportIssuesForm reportIssuesForm = new ReportIssuesForm();
                reportIssuesForm.Show();
                this.Hide();  // Hide the main form while the Report Issues form is open
            }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void BtnLocalEvents_Click(object sender, EventArgs e)
        {
            EventsForm EventsForm = new EventsForm();
            EventsForm.Show();
            this.Hide();  // Hide the main form while the Report Issues form is open
        }

        private void btnLEA_Click(object sender, EventArgs e)
        {
            EventsForm EventsForm = new EventsForm();
            EventsForm.Show();
            this.Hide();
        }

      

    }
}


