﻿using MunicipalServicesApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog7312_POE
{
    internal static class Program
    {
        /// <summary>
        public static List<User> RegisteredUsers = new List<User>();
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());  // Start with Login Form
           
        }
    }
}
