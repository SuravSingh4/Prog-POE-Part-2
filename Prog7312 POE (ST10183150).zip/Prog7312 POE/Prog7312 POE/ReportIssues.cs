﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog7312_POE
{

  
        public partial class ReportIssuesForm : Form
        {
            public ReportIssuesForm()
            {
                InitializeComponent();

            DateTimePicker dateTimePicker1 = new DateTimePicker(); dateTimePicker1.Location = new System.Drawing.Point(200, 150); // Adjust as needed
            dateTimePicker1.Name = "dateTimePickerIssueDate"; dateTimePicker1.Size = new System.Drawing.Size(200, 20); dateTimePicker1.Format = DateTimePickerFormat.Short; // Display date in short format (e.g., MM/DD/YYYY)
            dateTimePicker1.Value = DateTime.Now; // Set the default value to the current date


            dateTimePicker1.ValueChanged += new EventHandler((object sender, EventArgs e) => DateTimePicker1_ValueChanged(sender, e, dateTimePicker1)); // Event handler for date change
            // Initialize ProgressBar
            progressBar1.Minimum = 0;
                progressBar1.Maximum = 100;
                progressBar1.Value = 0;

                // Handle the text changes and other events to update the ProgressBar
                txtLocation.TextChanged += UpdateProgress;
                cmbCategory.SelectedIndexChanged += UpdateProgress;
                rtbDescription.TextChanged += UpdateProgress;
                btnAttachFile.Click += BtnAttachFile_Click;

                btnSubmit.Click += BtnSubmit_Click;
                btnBack.Click += BtnBack_Click;
            }

        private static void DateTimePicker1_ValueChanged(object sender, EventArgs e, DateTimePicker dateTimePicker1)
        {
            DateTime selectedDate = dateTimePicker1.Value;
            MessageBox.Show("The issue date has been changed to: " + selectedDate.ToShortDateString());
        }

        // Event handler for Attach File button
        private void BtnAttachFile_Click(object sender, EventArgs e)
            {
                OpenFileDialog fileDialog = new OpenFileDialog();
                fileDialog.Filter = "Image Files (*.jpg; *.png)|*.jpg; *.png|All Files (*.*)|*.*";
                if (fileDialog.ShowDialog() == DialogResult.OK)
                {
                    btnAttachFile.Text = fileDialog.FileName;
                    UpdateProgress(sender, e); // Update progress when a file is attached
                }
            }

            // Function to update the ProgressBar based on completed fields
            private void UpdateProgress(object sender, EventArgs e)
            {
                int progress = 0;

                // Check if the location field is filled
                if (!string.IsNullOrEmpty(txtLocation.Text))
                    progress += 25;

                // Check if a category is selected
                if (cmbCategory.SelectedIndex != -1)
                    progress += 25;

                // Check if the description is filled
                if (!string.IsNullOrEmpty(rtbDescription.Text))
                    progress += 25;

                // Check if a file is attached
                if (!string.IsNullOrEmpty(btnAttachFile.Text))
                    progress += 25;

                // Update ProgressBar value
                progressBar1.Value = progress;
            }

            // Event handler for Submit button
            private void BtnSubmit_Click(object sender, EventArgs e)
            {
                // Gather inputs
                string location = txtLocation.Text;
                string category = cmbCategory.SelectedItem?.ToString();
                string description = rtbDescription.Text;
                string mediaAttachment = btnAttachFile.Text;

                // Validate the inputs
                if (string.IsNullOrEmpty(location) || string.IsNullOrEmpty(category) || string.IsNullOrEmpty(description))
                {
                    MessageBox.Show("Please fill in all the required fields.", "Error");
                    return;
                }

                // Store the issue (this can be expanded to save to a database or list)
                IssueReport issue = new IssueReport(location, category, description, mediaAttachment);
                IssuesList.IssueReports.Add(issue);

                MessageBox.Show("Issue reported successfully!", "Success");

                // Reset the form after submission
                txtLocation.Clear();
                cmbCategory.SelectedIndex = -1;
                rtbDescription.Clear();
                //btnAttachFile.Clear();
                progressBar1.Value = 0;  // Reset the progress bar
            }

            // Event handler for Back button
            private void BtnBack_Click(object sender, EventArgs e)
            {
                this.Close();  // Close the current form
                MainForm mainForm = new MainForm();  // Reopen the main form
                mainForm.Show();
            }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void ReportIssuesForm_Load(object sender, EventArgs e)
        {
            cmbCategory.Items.Add("Sanitation");
            cmbCategory.Items.Add("Water");
            cmbCategory.Items.Add("Electricity");
            cmbCategory.Items.Add("Road Works");
            cmbCategory.Items.Add("Land Issues");

        }

        private void rtbDescription_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click_1(object sender, EventArgs e)
        {
            DateTime selectedDate = dateTimePicker1.Value; 
            MessageBox.Show("Selected Date: " + selectedDate.ToShortDateString());
        }

        private void btnBack_Click_1(object sender, EventArgs e)
        {

        }
    }
    }





